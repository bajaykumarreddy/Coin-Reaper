# Coin-Reaper
It is a simple casual fun 2D game wiritten in python using the library pygame where you have to collect random coins while escaping from fire at same time your score will be recorded and displayed at the end
Thank You :)
